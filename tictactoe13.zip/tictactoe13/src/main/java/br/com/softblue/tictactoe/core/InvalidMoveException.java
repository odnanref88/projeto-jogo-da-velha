package br.com.softblue.tictactoe.core;

public class InvalidMoveException extends Exception {

	

	public InvalidMoveException(String message) {
		super(message);
		
	}

}
